// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xfoc.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFoc_CfgInitialize(XFoc *InstancePtr, XFoc_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

u32 XFoc_Get_control_BaseAddress(XFoc *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_r_BaseAddress + XFOC_CONTROL_R_ADDR_CONTROL_BASE);
}

u32 XFoc_Get_control_HighAddress(XFoc *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_r_BaseAddress + XFOC_CONTROL_R_ADDR_CONTROL_HIGH);
}

u32 XFoc_Get_control_TotalBytes(XFoc *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XFOC_CONTROL_R_ADDR_CONTROL_HIGH - XFOC_CONTROL_R_ADDR_CONTROL_BASE + 1);
}

u32 XFoc_Get_control_BitWidth(XFoc *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFOC_CONTROL_R_WIDTH_CONTROL;
}

u32 XFoc_Get_control_Depth(XFoc *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFOC_CONTROL_R_DEPTH_CONTROL;
}

u32 XFoc_Write_control_Words(XFoc *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XFOC_CONTROL_R_ADDR_CONTROL_HIGH - XFOC_CONTROL_R_ADDR_CONTROL_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_r_BaseAddress + XFOC_CONTROL_R_ADDR_CONTROL_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XFoc_Read_control_Words(XFoc *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XFOC_CONTROL_R_ADDR_CONTROL_HIGH - XFOC_CONTROL_R_ADDR_CONTROL_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_r_BaseAddress + XFOC_CONTROL_R_ADDR_CONTROL_BASE + (offset + i)*4);
    }
    return length;
}

u32 XFoc_Write_control_Bytes(XFoc *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XFOC_CONTROL_R_ADDR_CONTROL_HIGH - XFOC_CONTROL_R_ADDR_CONTROL_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_r_BaseAddress + XFOC_CONTROL_R_ADDR_CONTROL_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XFoc_Read_control_Bytes(XFoc *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XFOC_CONTROL_R_ADDR_CONTROL_HIGH - XFOC_CONTROL_R_ADDR_CONTROL_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_r_BaseAddress + XFOC_CONTROL_R_ADDR_CONTROL_BASE + offset + i);
    }
    return length;
}

