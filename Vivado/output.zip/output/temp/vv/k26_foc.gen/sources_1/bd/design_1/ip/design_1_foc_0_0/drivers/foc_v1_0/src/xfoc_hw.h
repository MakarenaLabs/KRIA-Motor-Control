// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control_r
// 0x40 ~
// 0x7f : Memory 'control' (14 * 32b)
//        Word n : bit [31:0] - control[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XFOC_CONTROL_R_ADDR_CONTROL_BASE 0x40
#define XFOC_CONTROL_R_ADDR_CONTROL_HIGH 0x7f
#define XFOC_CONTROL_R_WIDTH_CONTROL     32
#define XFOC_CONTROL_R_DEPTH_CONTROL     14

